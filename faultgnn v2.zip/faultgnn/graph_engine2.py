# -*- coding: utf-8 -*-
"""
Fault Management 解析エンジン（実践版 / v2）

v1からの主な修正:
  - 埋め込みを「型シード付きランダム初期値のK-hop伝播」から
    「Fault×属性値 incidence -> TF-IDF -> TruncatedSVD -> (任意で)グラフ平滑化」に変更。
    v1は全Faultペアの類似度が0.9986〜1.0000に潰れており実質機能していなかった。
  - 原因予測から原因ノードを除外し、ラベルリークを排除。
  - ホールドアウト評価（Top-1/Top-3）とベースライン比較を内蔵。
  - 時系列列があれば「直近の急増パターン」を検出。
"""
from __future__ import annotations

import numpy as np
import pandas as pd
import networkx as nx
import scipy.sparse as sp
from collections import Counter, defaultdict
from functools import lru_cache

from sklearn.feature_extraction.text import TfidfTransformer
from sklearn.decomposition import TruncatedSVD
from sklearn.cluster import KMeans
from sklearn.ensemble import IsolationForest, HistGradientBoostingClassifier
from sklearn.preprocessing import OrdinalEncoder
from sklearn.model_selection import train_test_split
from sklearn.metrics import silhouette_score
from networkx.algorithms.community import greedy_modularity_communities

DEFAULT_ATTR_COLUMNS = ["装置", "部品", "症状", "Error", "条件", "工程"]
DEFAULT_CAUSE_COLUMN = "原因"
DEFAULT_ACTION_COLUMN = "対策"
DEFAULT_TEXT_COLUMN = "備考"
DEFAULT_DATE_COLUMN = "発生日"

# 高カーディナリティ列の除外閾値（ID列などがグラフを爆発させるのを防ぐ）
MAX_CARDINALITY_RATIO = 0.5
MAX_CARDINALITY_ABS = 500


class FaultAnalyzer:
    def __init__(
        self,
        df: pd.DataFrame,
        attr_columns=None,
        cause_column=DEFAULT_CAUSE_COLUMN,
        action_column=DEFAULT_ACTION_COLUMN,
        text_column=DEFAULT_TEXT_COLUMN,
        date_column=DEFAULT_DATE_COLUMN,
        n_components: int = 24,
        smooth_hops: int = 1,
        smooth_alpha: float = 0.3,
    ):
        self.df = df.reset_index(drop=True)
        cols = list(self.df.columns)

        self.cause_column = cause_column if cause_column in cols else None
        self.action_column = action_column if action_column in cols else None
        self.text_column = text_column if text_column in cols else None
        self.date_column = date_column if date_column in cols else None

        reserved = {self.cause_column, self.action_column, self.text_column, self.date_column}
        cand = [c for c in (attr_columns or DEFAULT_ATTR_COLUMNS) if c in cols and c not in reserved]
        # 高カーディナリティ列を除外（ID列対策）
        self.attr_columns, self.dropped_columns = [], []
        # 比率ルールは十分な行数がある場合のみ適用する。
        # 小規模データでは全列が誤って除外されてしまうため。
        apply_ratio = len(self.df) >= 50
        for c in cand:
            nu = self.df[c].nunique(dropna=True)
            too_many = nu > MAX_CARDINALITY_ABS or (apply_ratio and nu > MAX_CARDINALITY_RATIO * len(self.df))
            if too_many:
                self.dropped_columns.append({"column": c, "n_unique": int(nu)})
            else:
                self.attr_columns.append(c)
        if not self.attr_columns:
            raise ValueError("有効な属性列がありません（全列が高カーディナリティの可能性があります）")

        if self.date_column:
            self.df[self.date_column] = pd.to_datetime(self.df[self.date_column], errors="coerce")
            if self.df[self.date_column].isna().all():
                self.date_column = None

        self.fault_ids = [f"F{i:05d}" for i in self.df.index]
        self.n_components = n_components
        self.smooth_hops = smooth_hops
        self.smooth_alpha = smooth_alpha

        self._build_features()
        self._build_graph()
        self._smooth_embeddings()
        self._cache = {}

    # ---------------------------------------------------------------
    # 特徴量: Fault × 属性値 incidence -> TF-IDF
    #   TF-IDFにより「レアな属性値ほど情報量が大きい」ことを反映する。
    #   これは未知パターン発見・異常検知にとって本質的に重要。
    # ---------------------------------------------------------------
    @staticmethod
    def _nid(col, val):
        return f"{col}::{val}"

    def _build_features(self):
        vals = []
        for c in self.attr_columns:
            for v in self.df[c].dropna().unique():
                vals.append(self._nid(c, v))
        self.vocab = vals
        self.vocab_index = {v: i for i, v in enumerate(vals)}

        rows, cols_ = [], []
        for i, r in self.df.iterrows():
            for c in self.attr_columns:
                v = r.get(c)
                if pd.isna(v) or v == "":
                    continue
                rows.append(i)
                cols_.append(self.vocab_index[self._nid(c, v)])
        X = sp.csr_matrix(
            (np.ones(len(rows)), (rows, cols_)), shape=(len(self.df), len(vals))
        )
        self.X_raw = X
        self.tfidf = TfidfTransformer()
        self.X = self.tfidf.fit_transform(X)

        k = int(min(self.n_components, max(2, min(X.shape) - 1)))
        self.svd = TruncatedSVD(n_components=k, random_state=0)
        E = self.svd.fit_transform(self.X)
        self.E_base = self._l2(E)

    @staticmethod
    def _l2(M):
        n = np.linalg.norm(M, axis=1, keepdims=True)
        return M / np.maximum(n, 1e-9)

    # ---------------------------------------------------------------
    # グラフ（可視化・コミュニティ検出用。原因ノードは含めるが埋め込みには使わない）
    # ---------------------------------------------------------------
    def _build_graph(self):
        """異種グラフの統計値のみを算出する。
        コミュニティ検出を属性グラフ側に移したため、Faultノードを含む
        巨大グラフを networkx で実体化する必要がなくなった。"""
        self.n_graph_nodes = int(len(self.df) + len(self.vocab))
        self.n_graph_edges = int(self.X_raw.nnz)

    def _smooth_embeddings(self):
        """Fault-Fault の共有属性グラフ上でのメッセージパッシング（GNN相当）。

        概念上は S = X Xᵀ（Fault間類似度）を行正規化した P で E <- (1-a)E + a P E。
        ただし S を実体化すると O(n^2) メモリで大規模データが破綻するため
        （実測: 5,000件で77%密、20,000件でOOM）、結合則を使って
            S E = X (Xᵀ E)
        と計算する。X は L2正規化済みなので diag(S)=1 であり、自己ループ除去は -E で足りる。
        計算量は O(nnz · d) となり n に線形。
        """
        E = self.E_base
        if self.smooth_hops <= 0 or self.smooth_alpha <= 0:
            self.E = E
            return
        X = self.X
        ones = np.ones((X.shape[0], 1))
        deg = np.asarray(X @ (X.T @ ones)).ravel() - 1.0  # 自己類似度(=1)を除く
        deg[deg <= 1e-12] = 1.0
        inv = (1.0 / deg)[:, None]
        for _ in range(self.smooth_hops):
            agg = X @ (X.T @ E) - E  # = S_offdiag @ E （n×n を作らない）
            E = (1 - self.smooth_alpha) * E + self.smooth_alpha * (inv * agg)
        self.E = self._l2(E)

    # ---------------------------------------------------------------
    def embed_query(self, attrs: dict):
        cols_, data = [], []
        for c, v in (attrs or {}).items():
            if v in (None, ""):
                continue
            key = self._nid(c, v)
            if key in self.vocab_index:
                cols_.append(self.vocab_index[key])
                data.append(1.0)
        if not cols_:
            return None
        x = sp.csr_matrix((data, ([0] * len(cols_), cols_)), shape=(1, len(self.vocab)))
        x = self.tfidf.transform(x)
        e = self.svd.transform(x)
        return self._l2(e)[0]

    # ---------------------------------------------------------------
    # ① 原因予測（ラベルリークなし: 埋め込みは属性のみから構成）
    # ---------------------------------------------------------------
    def predict_cause(self, attrs: dict, top_k=5, knn=25):
        if not self.cause_column:
            raise ValueError("データに原因列がありません")
        q = self.embed_query(attrs)
        if q is None:
            return []
        sims = self.E @ q
        order = np.argsort(-sims)[:knn]
        w = Counter()
        ev = defaultdict(list)
        for i in order:
            c = self.df.iloc[i].get(self.cause_column)
            if pd.isna(c) or c == "":
                continue
            s = max(float(sims[i]), 0.0)
            w[c] += s + 1e-9
            ev[c].append({"fault_id": self.fault_ids[i], "similarity": round(s * 100, 1)})
        if not w:
            return []
        tot = sum(w.values())
        return [
            {
                "cause": c,
                "probability": round(100 * v / tot, 1),
                "evidence": sorted(ev[c], key=lambda e: -e["similarity"])[:3],
            }
            for c, v in sorted(w.items(), key=lambda x: -x[1])[:top_k]
        ]

    # ---------------------------------------------------------------
    # 評価: ホールドアウトでTop-1/Top-3、ベースラインと勾配ブースティングを比較
    # ---------------------------------------------------------------
    def evaluate_cause_model(self, test_size=0.3, knn=25, random_state=0):
        if not self.cause_column:
            raise ValueError("原因列がないため評価できません")
        y = self.df[self.cause_column].astype(str).values
        mask = pd.notna(self.df[self.cause_column])
        idx = np.where(mask)[0]
        if len(idx) < 30:
            raise ValueError("評価には最低30件の原因ラベルが必要です")

        vc = pd.Series(y[idx]).value_counts()
        strat = y[idx] if (vc.min() >= 2 and len(vc) > 1) else None
        tr, te = train_test_split(idx, test_size=test_size, random_state=random_state, stratify=strat)

        # (a) 多数決ベースライン
        maj = Counter(y[tr]).most_common(1)[0][0]
        base1 = float(np.mean(y[te] == maj))

        # (b) 埋め込みkNN（本アプリ①の方式）
        # 全テスト件×全学習件の類似度行列を一度に作るとメモリが O(|te|·|tr|) で
        # 破綻するため（10万件で15.6GiB要求）、テスト側をチャンクに分けて処理する。
        Etr, Ete = self.E[tr], self.E[te]
        k1 = k3 = 0
        chunk = max(1, int(2_000_000 // max(len(tr), 1)))
        for s0 in range(0, len(te), chunk):
            S = Ete[s0 : s0 + chunk] @ Etr.T
            for i in range(S.shape[0]):
                o = np.argpartition(-S[i], min(knn, S.shape[1] - 1))[:knn]
                w = Counter()
                for j in o:
                    w[y[tr[j]]] += max(float(S[i, j]), 0.0) + 1e-9
                top = [c for c, _ in w.most_common(3)]
                gt = y[te[s0 + i]]
                if top and top[0] == gt:
                    k1 += 1
                if gt in top:
                    k3 += 1
            del S
        knn1, knn3 = k1 / len(te), k3 / len(te)

        # (c) 勾配ブースティング（CatBoost相当のリファレンス）
        enc = OrdinalEncoder(handle_unknown="use_encoded_value", unknown_value=-1)
        Xc = enc.fit_transform(self.df[self.attr_columns].astype(str))
        gb = HistGradientBoostingClassifier(
            categorical_features=list(range(len(self.attr_columns))), random_state=0
        ).fit(Xc[tr], y[tr])
        proba = gb.predict_proba(Xc[te])
        cls = gb.classes_
        gb1 = float(np.mean(cls[proba.argmax(1)] == y[te]))
        gb3 = float(
            np.mean([y[te[i]] in cls[np.argsort(-proba[i])[:3]] for i in range(len(te))])
        )

        return {
            "n_train": int(len(tr)),
            "n_test": int(len(te)),
            "n_classes": int(len(set(y[idx]))),
            "rows": [
                {"model": "多数決ベースライン", "top1": round(base1, 3), "top3": None},
                {"model": "埋め込みkNN（本アプリ①）", "top1": round(knn1, 3), "top3": round(knn3, 3)},
                {"model": "勾配ブースティング（CatBoost相当）", "top1": round(gb1, 3), "top3": round(gb3, 3)},
            ],
        }

    # ---------------------------------------------------------------
    # ② パターン発見
    # ---------------------------------------------------------------
    def discover_patterns(self, n_clusters=None, contamination=0.08, recent_days=90):
        X = self.E
        n = len(X)

        # クラスタ数をシルエット係数で自動選択
        chosen_k, sil_scores = None, []
        if n_clusters:
            chosen_k = max(2, min(int(n_clusters), n - 1))
        elif n >= 20:
            best = (-1, None)
            for k in range(2, min(11, n // 5 + 1)):
                lab = KMeans(n_clusters=k, n_init=10, random_state=0).fit_predict(X)
                if len(set(lab)) < 2:
                    continue
                s = float(silhouette_score(X, lab, sample_size=min(2000, n), random_state=0))
                sil_scores.append({"k": k, "silhouette": round(s, 3)})
                if s > best[0]:
                    best = (s, k)
            chosen_k = best[1]

        clusters = []
        if chosen_k and n > chosen_k:
            lab = KMeans(n_clusters=chosen_k, n_init=10, random_state=0).fit_predict(X)
            for c in range(chosen_k):
                ix = np.where(lab == c)[0]
                if not len(ix):
                    continue
                sub = self.df.iloc[ix]
                # 全体分布に対するリフト値で「そのクラスタらしさ」を出す
                feats = []
                for col in self.attr_columns:
                    vc = sub[col].value_counts(normalize=True)
                    gl = self.df[col].value_counts(normalize=True)
                    for v, p in vc.head(2).items():
                        lift = p / gl.get(v, 1e-9)
                        if lift > 1.2 and p > 0.2:
                            feats.append(
                                {
                                    "col": col,
                                    "val": str(v),
                                    "share": round(float(p) * 100, 1),
                                    "lift": round(float(lift), 2),
                                }
                            )
                feats.sort(key=lambda f: -f["lift"])
                tc = None
                if self.cause_column:
                    cv = sub[self.cause_column].value_counts()
                    if len(cv):
                        tc = f"{cv.index[0]}({cv.iloc[0]}/{len(ix)}件)"
                clusters.append(
                    {
                        "cluster_id": int(c),
                        "size": int(len(ix)),
                        "features": feats[:6],
                        "top_cause": tc,
                        "fault_ids": [self.fault_ids[i] for i in ix[:12]],
                    }
                )
            clusters.sort(key=lambda c: -c["size"])

        # 異常検知
        anomalies = []
        if n >= 20:
            iso = IsolationForest(contamination=contamination, random_state=0).fit(X)
            sc = -iso.score_samples(X)
            ax = np.where(iso.predict(X) == -1)[0]
            ax = ax[np.argsort(-sc[ax])]
            for i in ax[:20]:
                r = self.df.iloc[i]
                anomalies.append(
                    {
                        "fault_id": self.fault_ids[i],
                        "anomaly_score": round(float(sc[i]), 3),
                        "attrs": {c: str(r[c]) for c in self.attr_columns if pd.notna(r.get(c))},
                        "cause": str(r[self.cause_column])
                        if self.cause_column and pd.notna(r.get(self.cause_column))
                        else None,
                    }
                )

        return {
            "clusters": clusters,
            "anomalies": anomalies,
            "silhouette": sil_scores,
            "chosen_k": chosen_k,
            "communities": self._communities(),
            "network": self._network(),
            "surges": self._detect_surges(recent_days),
        }

    def _cooccurrence(self):
        """属性値どうしの共起行列を疎行列積で一括計算する。
        v1はPythonの二重ループで O(行数 × 列数^2) かかり5,000件で約96秒だった。
        C = Bᵀ B（B は Fault×属性値 の 0/1 行列）で同じ結果が線形代数で得られる。"""
        if "cooc" in self._cache:
            return self._cache["cooc"]

        cols = self.attr_columns + ([self.cause_column] if self.cause_column else [])
        vocab, vidx = [], {}
        for c in cols:
            for v in self.df[c].dropna().unique():
                k = self._nid(c, v)
                if k not in vidx:
                    vidx[k] = len(vocab)
                    vocab.append(k)
        rows, cs = [], []
        for i, r in enumerate(self.df.itertuples(index=False)):
            d = r._asdict() if hasattr(r, "_asdict") else None
            for c in cols:
                v = self.df.iat[i, self.df.columns.get_loc(c)]
                if pd.isna(v) or v == "":
                    continue
                rows.append(i)
                cs.append(vidx[self._nid(c, v)])
        B = sp.csr_matrix((np.ones(len(rows)), (rows, cs)), shape=(len(self.df), len(vocab)))
        counts = np.asarray(B.sum(0)).ravel()
        C = (B.T @ B).tocoo()
        self._cache["cooc"] = (vocab, counts, C)
        return self._cache["cooc"]

    def _attr_graph(self, max_nodes=80):
        """属性値ノードのみの重み付き共起グラフ。
        コミュニティ検出はこの小さなグラフ（最大80ノード）上で行う。
        v1はFaultノードを含む全グラフ上で実行しており5,000件で約91秒かかっていた。"""
        if "ag" in self._cache:
            return self._cache["ag"]
        vocab, counts, C = self._cooccurrence()
        top = set(np.argsort(-counts)[:max_nodes].tolist())
        H = nx.Graph()
        for i in top:
            H.add_node(vocab[i], count=int(counts[i]))
        for i, j, w in zip(C.row, C.col, C.data):
            if i < j and i in top and j in top and w > 0:
                H.add_edge(vocab[i], vocab[j], weight=float(w))
        self._cache["ag"] = H
        return H

    def _communities(self):
        if "comm" in self._cache:
            return self._cache["comm"]
        H = self._attr_graph()
        try:
            coms = list(greedy_modularity_communities(H, weight="weight")) if H.number_of_edges() else []
        except Exception:
            coms = []
        n2c, out = {}, []
        for ci, com in enumerate(coms):
            members = sorted(com, key=lambda x: -H.nodes[x].get("count", 0))
            for x in members:
                n2c[x] = ci
            out.append(
                {
                    "community_id": ci,
                    "n_faults": int(sum(H.nodes[x].get("count", 0) for x in members)),
                    "key_attrs": [x.replace("::", ": ") for x in members[:10]],
                }
            )
        out.sort(key=lambda c: -c["n_faults"])
        self._cache["comm"] = out[:10]
        self._cache["n2c"] = n2c
        return self._cache["comm"]

    def _network(self, max_nodes=60, max_edges=300):
        if "net" in self._cache:
            return self._cache["net"]
        self._communities()
        n2c = self._cache.get("n2c", {})
        vocab, counts, C = self._cooccurrence()
        top = set(np.argsort(-counts)[:max_nodes].tolist())
        eg = sorted(
            [(int(i), int(j), float(w)) for i, j, w in zip(C.row, C.col, C.data) if i < j and i in top and j in top],
            key=lambda e: -e[2],
        )[:max_edges]
        used = {x for a, b, _ in eg for x in (a, b)}
        nodes = []
        for i in used:
            col, val = vocab[i].split("::", 1)
            nodes.append(
                {
                    "id": vocab[i],
                    "label": str(val),
                    "type": col,
                    "count": int(counts[i]),
                    "community": n2c.get(vocab[i], -1),
                }
            )
        self._cache["net"] = {
            "nodes": nodes,
            "edges": [{"from": vocab[a], "to": vocab[b], "weight": int(w)} for a, b, w in eg],
        }
        return self._cache["net"]

    def _detect_surges(self, recent_days=90, min_recent=3):
        """直近期間で構成比が有意に増えた属性組合せを検出（元資料の『最近急増』要件）。"""
        if not self.date_column:
            return {"available": False, "reason": "日付列がないため急増検知は実行できません", "items": []}
        d = self.df[self.date_column]
        tmax = d.max()
        if pd.isna(tmax):
            return {"available": False, "reason": "日付をパースできませんでした", "items": []}
        cut = tmax - pd.Timedelta(days=recent_days)
        rec, prev = d > cut, d <= cut
        nr, npv = int(rec.sum()), int(prev.sum())
        if nr < min_recent or npv < min_recent:
            return {"available": False, "reason": "比較に十分な期間データがありません", "items": []}

        items = []
        cols = self.attr_columns
        for a in range(len(cols)):
            for b in range(a + 1, len(cols)):
                ca, cb = cols[a], cols[b]
                key = self.df[ca].astype(str) + " × " + self.df[cb].astype(str)
                rc, pc = key[rec].value_counts(), key[prev].value_counts()
                for k, cnt in rc.items():
                    if cnt < min_recent:
                        continue
                    p_rec = cnt / nr
                    p_prev = pc.get(k, 0) / npv
                    lift = p_rec / p_prev if p_prev > 0 else float("inf")
                    if lift >= 2.0:
                        items.append(
                            {
                                "pattern": f"{ca}×{cb}: {k}",
                                "recent_count": int(cnt),
                                "recent_share": round(p_rec * 100, 2),
                                "prev_share": round(p_prev * 100, 2),
                                "lift": "新規出現" if p_prev == 0 else round(lift, 2),
                                "_sort": 1e9 if p_prev == 0 else lift,
                            }
                        )
        items.sort(key=lambda x: (-x["_sort"], -x["recent_count"]))
        for it in items:
            it.pop("_sort", None)
        return {
            "available": True,
            "recent_days": recent_days,
            "n_recent": nr,
            "n_prev": npv,
            "items": items[:15],
        }

    # ---------------------------------------------------------------
    # ③ 類似検索
    # ---------------------------------------------------------------
    def find_similar(self, fault_index=None, attrs=None, top_k=10):
        if fault_index is not None:
            q = self.E[fault_index]
        else:
            q = self.embed_query(attrs or {})
            if q is None:
                return []
        sims = self.E @ q
        out = []
        for i in np.argsort(-sims):
            if fault_index is not None and i == fault_index:
                continue
            r = self.df.iloc[i]
            item = {
                "fault_id": self.fault_ids[i],
                "similarity": round(float(sims[i]) * 100, 1),
                "attrs": {c: str(r[c]) for c in self.attr_columns if pd.notna(r.get(c))},
            }
            for key, col in (("cause", self.cause_column), ("action", self.action_column), ("note", self.text_column)):
                if col and pd.notna(r.get(col)):
                    item[key] = str(r[col])
            if self.date_column and pd.notna(r.get(self.date_column)):
                item["date"] = str(pd.to_datetime(r[self.date_column]).date())
            out.append(item)
            if len(out) >= top_k:
                break
        return out

    # ---------------------------------------------------------------
    def attr_value_options(self):
        return {c: sorted(map(str, self.df[c].dropna().unique().tolist())) for c in self.attr_columns}

    def summary(self):
        return {
            "n_faults": int(len(self.df)),
            "n_nodes": self.n_graph_nodes,
            "n_edges": self.n_graph_edges,
            "attr_columns": self.attr_columns,
            "cause_column": self.cause_column,
            "date_column": self.date_column,
            "dropped_columns": self.dropped_columns,
            "embed_dim": int(self.E.shape[1]),
        }
