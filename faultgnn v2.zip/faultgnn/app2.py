# -*- coding: utf-8 -*-
"""Fault Management 解析アプリ（実践版 / v2）

v1からのセキュリティ・運用面の修正:
  - secret_key を環境変数化、debug をデフォルト無効
  - アップロードサイズ上限（MAX_CONTENT_LENGTH）
  - セッションストアにLRU上限とTTLを設定（v1は無制限に増え続けメモリリーク）
  - 全APIで例外を捕捉しトレースバックを外部に漏らさない
"""
from __future__ import annotations

import io
import os
import time
import uuid
import logging
import threading
from collections import OrderedDict

import pandas as pd
from flask import Flask, request, jsonify, session, render_template

from graph_engine2 import (
    FaultAnalyzer,
    DEFAULT_ATTR_COLUMNS,
    DEFAULT_CAUSE_COLUMN,
    DEFAULT_ACTION_COLUMN,
    DEFAULT_TEXT_COLUMN,
    DEFAULT_DATE_COLUMN,
)
from sample_data import build_sample_dataframe

logging.basicConfig(level=logging.INFO)
log = logging.getLogger(__name__)

MAX_UPLOAD_MB = int(os.environ.get("MAX_UPLOAD_MB", "32"))
MAX_ROWS = int(os.environ.get("MAX_ROWS", "200000"))
STORE_CAPACITY = int(os.environ.get("STORE_CAPACITY", "32"))
STORE_TTL_SEC = int(os.environ.get("STORE_TTL_SEC", str(60 * 60)))

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY") or os.urandom(32)
app.config["MAX_CONTENT_LENGTH"] = MAX_UPLOAD_MB * 1024 * 1024
app.config.update(SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Lax")


class TTLStore:
    """LRU + TTL 付きのプロセス内ストア。
    複数ワーカー構成では Redis 等に置き換えること。"""

    def __init__(self, capacity, ttl):
        self._d = OrderedDict()
        self._cap, self._ttl = capacity, ttl
        self._lock = threading.Lock()

    def _purge(self):
        now = time.time()
        for k in [k for k, (t, _) in self._d.items() if now - t > self._ttl]:
            self._d.pop(k, None)
        while len(self._d) > self._cap:
            self._d.popitem(last=False)

    def put(self, k, v):
        with self._lock:
            self._d[k] = (time.time(), v)
            self._d.move_to_end(k)
            self._purge()

    def get(self, k):
        with self._lock:
            self._purge()
            if k not in self._d:
                return None
            self._d.move_to_end(k)
            return self._d[k][1]


STORE = TTLStore(STORE_CAPACITY, STORE_TTL_SEC)


def _analyzer():
    tok = session.get("token")
    a = STORE.get(tok) if tok else None
    if a is None:
        raise LookupError("データが読み込まれていません（またはセッションが期限切れです）。再度読み込んでください。")
    return a


def _register(a):
    tok = str(uuid.uuid4())
    STORE.put(tok, a)
    session["token"] = tok


def _loaded_payload(a):
    return jsonify(
        {
            "ok": True,
            "summary": a.summary(),
            "attr_options": a.attr_value_options(),
            "preview": a.df.head(8).astype(str).to_dict(orient="records"),
            "columns": list(map(str, a.df.columns)),
        }
    )


def api_guard(fn):
    """例外を握りつぶしてスタックトレースの外部漏洩を防ぐデコレータ。"""

    def wrapper(*args, **kwargs):
        try:
            return fn(*args, **kwargs)
        except LookupError as e:
            return jsonify({"ok": False, "error": str(e)}), 400
        except ValueError as e:
            return jsonify({"ok": False, "error": str(e)}), 400
        except Exception:
            log.exception("unhandled error in %s", fn.__name__)
            return jsonify({"ok": False, "error": "サーバー内部エラーが発生しました。"}), 500

    wrapper.__name__ = fn.__name__
    return wrapper


@app.errorhandler(413)
def too_large(e):
    return jsonify({"ok": False, "error": f"ファイルが大きすぎます（上限{MAX_UPLOAD_MB}MB）"}), 413


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/load_sample", methods=["POST"])
@api_guard
def load_sample():
    a = FaultAnalyzer(build_sample_dataframe())
    _register(a)
    return _loaded_payload(a)


@app.route("/api/upload", methods=["POST"])
@api_guard
def upload():
    if "file" not in request.files:
        return jsonify({"ok": False, "error": "ファイルが見つかりません"}), 400
    raw = request.files["file"].read()
    df = None
    for enc in ("utf-8-sig", "cp932", "utf-16"):
        try:
            df = pd.read_csv(io.BytesIO(raw), encoding=enc)
            break
        except (UnicodeDecodeError, UnicodeError):
            continue
        except Exception as e:
            return jsonify({"ok": False, "error": f"CSVの解析に失敗しました: {e}"}), 400
    if df is None or df.empty:
        return jsonify({"ok": False, "error": "CSVを読み込めませんでした（文字コードをUTF-8にしてください）"}), 400
    if len(df) > MAX_ROWS:
        return jsonify({"ok": False, "error": f"行数が上限({MAX_ROWS:,}行)を超えています"}), 400

    reserved = {DEFAULT_CAUSE_COLUMN, DEFAULT_ACTION_COLUMN, DEFAULT_TEXT_COLUMN, DEFAULT_DATE_COLUMN}
    attrs = [c for c in DEFAULT_ATTR_COLUMNS if c in df.columns]
    if not attrs:
        attrs = [c for c in df.columns if c not in reserved][:8]

    a = FaultAnalyzer(df, attr_columns=attrs)
    _register(a)
    return _loaded_payload(a)


@app.route("/api/predict_cause", methods=["POST"])
@api_guard
def predict_cause():
    d = request.get_json(silent=True) or {}
    return jsonify({"ok": True, "result": _analyzer().predict_cause(d.get("attrs", {}), top_k=int(d.get("top_k", 5)))})


@app.route("/api/evaluate", methods=["POST"])
@api_guard
def evaluate():
    return jsonify({"ok": True, "result": _analyzer().evaluate_cause_model()})


@app.route("/api/discover_patterns", methods=["POST"])
@api_guard
def discover_patterns():
    d = request.get_json(silent=True) or {}
    nc = d.get("n_clusters")
    return jsonify(
        {
            "ok": True,
            "result": _analyzer().discover_patterns(
                n_clusters=int(nc) if nc else None,
                contamination=float(d.get("contamination", 0.08)),
                recent_days=int(d.get("recent_days", 90)),
            ),
        }
    )


@app.route("/api/find_similar", methods=["POST"])
@api_guard
def find_similar():
    d = request.get_json(silent=True) or {}
    a = _analyzer()
    k = int(d.get("top_k", 10))
    fid = d.get("fault_id")
    if fid:
        if fid not in a.fault_ids:
            return jsonify({"ok": False, "error": f"Fault ID '{fid}' が見つかりません"}), 400
        return jsonify({"ok": True, "result": a.find_similar(fault_index=a.fault_ids.index(fid), top_k=k)})
    return jsonify({"ok": True, "result": a.find_similar(attrs=d.get("attrs") or {}, top_k=k)})


@app.route("/api/fault_ids", methods=["GET"])
@api_guard
def fault_ids():
    return jsonify({"ok": True, "fault_ids": _analyzer().fault_ids})


if __name__ == "__main__":
    app.run(
        host=os.environ.get("HOST", "127.0.0.1"),
        port=int(os.environ.get("PORT", "5000")),
        debug=os.environ.get("FLASK_DEBUG", "0") == "1",
    )
