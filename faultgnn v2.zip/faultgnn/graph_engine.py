# -*- coding: utf-8 -*-
"""
Fault Management データを異種グラフ（Heterogeneous Graph）として構築し、
簡易GNN（SGC: Simple Graph Convolution 方式 = 正規化隣接行列によるK-hop特徴伝播）で
ノード埋め込みを計算し、以下3手法を実装するコアモジュール。

  1) 原因予測      : Node Classification / Link Prediction 相当
  2) 未知パターン発見: Embedding + Clustering / Community Detection / Anomaly Detection
  3) 類似Fault検索  : Graph Embedding + Similarity (cosine)
"""
from __future__ import annotations

import numpy as np
import pandas as pd
import networkx as nx
import scipy.sparse as sp
from collections import Counter
from sklearn.cluster import KMeans
from sklearn.ensemble import IsolationForest
from networkx.algorithms.community import greedy_modularity_communities

DEFAULT_ATTR_COLUMNS = ["装置", "部品", "症状", "Error", "条件", "工程"]
DEFAULT_CAUSE_COLUMN = "原因"
DEFAULT_ACTION_COLUMN = "対策"
DEFAULT_TEXT_COLUMN = "備考"


class FaultGraphAnalyzer:
    def __init__(
        self,
        df: pd.DataFrame,
        attr_columns=None,
        cause_column=DEFAULT_CAUSE_COLUMN,
        action_column=DEFAULT_ACTION_COLUMN,
        text_column=DEFAULT_TEXT_COLUMN,
        hops: int = 2,
        embed_dim: int = 32,
        seed: int = 42,
    ):
        self.df = df.reset_index(drop=True)
        cols = list(self.df.columns)
        self.attr_columns = [c for c in (attr_columns or DEFAULT_ATTR_COLUMNS) if c in cols]
        self.cause_column = cause_column if cause_column in cols else None
        self.action_column = action_column if action_column in cols else None
        self.text_column = text_column if text_column in cols else None
        self.hops = hops
        self.embed_dim = embed_dim
        self.rng = np.random.default_rng(seed)

        self.fault_ids = [f"F{idx:05d}" for idx in self.df.index]
        self.G = nx.Graph()
        self._build_graph()
        self._propagate_embeddings()

    # ---------------------------------------------------------------
    # グラフ構築
    # ---------------------------------------------------------------
    @staticmethod
    def _node_id(col, val):
        return f"{col}::{val}"

    def _build_graph(self):
        for i, row in self.df.iterrows():
            fid = self.fault_ids[i]
            self.G.add_node(fid, ntype="Fault")
            for col in self.attr_columns:
                val = row.get(col)
                if pd.isna(val) or val == "":
                    continue
                nid = self._node_id(col, val)
                if nid not in self.G:
                    self.G.add_node(nid, ntype=col)
                self.G.add_edge(fid, nid)
            if self.cause_column:
                val = row.get(self.cause_column)
                if pd.notna(val) and val != "":
                    nid = self._node_id(self.cause_column, val)
                    if nid not in self.G:
                        self.G.add_node(nid, ntype=self.cause_column)
                    self.G.add_edge(fid, nid, cause_edge=True)

    # ---------------------------------------------------------------
    # 簡易GNN: 正規化隣接行列 A_hat による K-hop 特徴伝播 (SGC 方式)
    #   H^(k) = A_hat^k * X0   (X0 はノード種別ごとのランダム初期特徴)
    # ---------------------------------------------------------------
    def _propagate_embeddings(self):
        nodes = list(self.G.nodes())
        self.node_index = {n: i for i, n in enumerate(nodes)}
        n = len(nodes)

        type_seed = {}
        X0 = np.zeros((n, self.embed_dim))
        for node in nodes:
            ntype = self.G.nodes[node]["ntype"]
            if ntype not in type_seed:
                type_seed[ntype] = self.rng.normal(0, 1.0, self.embed_dim)
            base = type_seed[ntype]
            noise = self.rng.normal(0, 0.35, self.embed_dim)
            X0[self.node_index[node]] = base + noise

        A = nx.to_scipy_sparse_array(self.G, nodelist=nodes, format="csr", dtype=float)
        A = A + sp.eye(n, format="csr")  # self-loop
        deg = np.asarray(A.sum(1)).flatten()
        deg_inv_sqrt = np.zeros_like(deg)
        nz = deg > 0
        deg_inv_sqrt[nz] = np.power(deg[nz], -0.5)
        D_inv_sqrt = sp.diags(deg_inv_sqrt)
        A_hat = D_inv_sqrt @ A @ D_inv_sqrt

        H = X0
        for _ in range(self.hops):
            H = A_hat @ H

        norms = np.linalg.norm(H, axis=1, keepdims=True)
        norms[norms == 0] = 1.0
        self.embeddings = H / norms
        self.nodes = nodes

    def embedding_of(self, node_id):
        return self.embeddings[self.node_index[node_id]]

    def fault_embedding(self, i):
        return self.embedding_of(self.fault_ids[i])

    def all_fault_embeddings(self):
        idx = [self.node_index[fid] for fid in self.fault_ids]
        return self.embeddings[idx]

    def embed_query(self, attrs: dict):
        """未知Faultの属性(dict: 列名->値)から、既存の属性ノード埋め込みの平均でクエリ埋め込みを作る。"""
        vecs = []
        for col, val in attrs.items():
            if val in (None, ""):
                continue
            nid = self._node_id(col, val)
            if nid in self.node_index:
                vecs.append(self.embedding_of(nid))
        if not vecs:
            return np.zeros(self.embed_dim)
        v = np.mean(vecs, axis=0)
        norm = np.linalg.norm(v)
        return v / norm if norm > 0 else v

    # ---------------------------------------------------------------
    # ① 原因予測 (Node Classification / Link Prediction 相当)
    # ---------------------------------------------------------------
    def predict_cause(self, attrs: dict, top_k=5, knn=20):
        if not self.cause_column:
            raise ValueError("データに原因列がありません")
        q = self.embed_query(attrs)
        fault_embs = self.all_fault_embeddings()
        sims = fault_embs @ q
        order = np.argsort(-sims)[:knn]

        weight_sum = Counter()
        evidence = {}
        for idx in order:
            cause = self.df.iloc[idx].get(self.cause_column)
            if pd.isna(cause) or cause == "":
                continue
            w = max(float(sims[idx]), 0.0) + 1e-6
            weight_sum[cause] += w
            evidence.setdefault(cause, []).append(
                {"fault_id": self.fault_ids[idx], "similarity": round(float(sims[idx]) * 100, 1)}
            )
        total = sum(weight_sum.values()) or 1.0
        ranked = sorted(weight_sum.items(), key=lambda x: -x[1])[:top_k]
        return [
            {
                "cause": c,
                "probability": round(100 * w / total, 1),
                "evidence": sorted(evidence[c], key=lambda e: -e["similarity"])[:3],
            }
            for c, w in ranked
        ]

    # ---------------------------------------------------------------
    # ② 未知パターン発見 (Clustering / Community Detection / Anomaly Detection)
    # ---------------------------------------------------------------
    def discover_patterns(self, n_clusters=None, contamination=0.08):
        X = self.all_fault_embeddings()
        n = len(X)
        if n_clusters is None:
            n_clusters = max(2, min(8, n // 15)) if n >= 10 else min(2, n)
        n_clusters = max(1, min(n_clusters, n))

        clusters = []
        if n_clusters >= 2 and n >= n_clusters:
            km = KMeans(n_clusters=n_clusters, n_init=10, random_state=0).fit(X)
            labels = km.labels_
            for c in range(n_clusters):
                idxs = np.where(labels == c)[0]
                if len(idxs) == 0:
                    continue
                sub = self.df.iloc[idxs]
                top_attrs = {}
                for col in self.attr_columns:
                    vc = sub[col].value_counts()
                    if len(vc):
                        top_attrs[col] = f"{vc.index[0]}（{vc.iloc[0]}/{len(idxs)}件）"
                top_cause = None
                if self.cause_column and self.cause_column in sub:
                    vc = sub[self.cause_column].value_counts()
                    if len(vc):
                        top_cause = f"{vc.index[0]}（{vc.iloc[0]}/{len(idxs)}件）"
                clusters.append(
                    {
                        "cluster_id": int(c),
                        "size": int(len(idxs)),
                        "top_attrs": top_attrs,
                        "top_cause": top_cause,
                        "fault_ids": [self.fault_ids[i] for i in idxs[:12]],
                    }
                )
            clusters.sort(key=lambda c: -c["size"])

        anomalies = []
        if n >= 10:
            iso = IsolationForest(contamination=contamination, random_state=0).fit(X)
            pred = iso.predict(X)
            scores = -iso.score_samples(X)
            anomaly_idx = np.where(pred == -1)[0]
            anomaly_idx = anomaly_idx[np.argsort(-scores[anomaly_idx])]
            for i in anomaly_idx[:20]:
                row = self.df.iloc[i]
                attrs = {col: row[col] for col in self.attr_columns if pd.notna(row.get(col))}
                anomalies.append(
                    {
                        "fault_id": self.fault_ids[i],
                        "anomaly_score": round(float(scores[i]), 3),
                        "attrs": attrs,
                        "cause": row.get(self.cause_column) if self.cause_column and pd.notna(row.get(self.cause_column)) else None,
                    }
                )

        try:
            communities = list(greedy_modularity_communities(self.G))
        except Exception:
            communities = []

        # 属性ノード -> コミュニティID（共起ネットワークの色分けに再利用する）
        node_to_community = {}
        for ci, com in enumerate(communities):
            for node in com:
                if self.G.nodes[node]["ntype"] != "Fault":
                    node_to_community[node] = ci

        community_summaries = []
        for ci, com in enumerate(communities):
            fault_nodes = [x for x in com if self.G.nodes[x]["ntype"] == "Fault"]
            attr_nodes = [x for x in com if self.G.nodes[x]["ntype"] != "Fault"]
            if len(fault_nodes) < 2:
                continue
            community_summaries.append(
                {
                    "community_id": ci,
                    "n_faults": len(fault_nodes),
                    "key_attrs": [n.replace("::", ": ") for n in attr_nodes[:10]],
                }
            )
        community_summaries.sort(key=lambda c: -c["n_faults"])

        network = self._build_cooccurrence_network(node_to_community)

        return {
            "clusters": clusters,
            "anomalies": anomalies,
            "communities": community_summaries[:10],
            "network": network,
        }

    # ---------------------------------------------------------------
    # 共起ネットワーク（属性値どうしが同一Faultに現れた回数をエッジ重みとする）
    # ノードの色分け(group)は上のコミュニティ検出結果を再利用する
    # ---------------------------------------------------------------
    def _build_cooccurrence_network(self, node_to_community, max_nodes=60, max_edges=350):
        from collections import defaultdict

        edge_weight = defaultdict(int)
        node_count = Counter()
        cols = self.attr_columns + ([self.cause_column] if self.cause_column else [])

        for _, row in self.df.iterrows():
            present = []
            for col in cols:
                val = row.get(col)
                if pd.notna(val) and val != "":
                    present.append(self._node_id(col, val))
            for p in present:
                node_count[p] += 1
            for a in range(len(present)):
                for b in range(a + 1, len(present)):
                    key = tuple(sorted((present[a], present[b])))
                    edge_weight[key] += 1

        top_nodes = [n for n, _ in node_count.most_common(max_nodes)]
        top_set = set(top_nodes)

        edges = [(a, b, w) for (a, b), w in edge_weight.items() if a in top_set and b in top_set]
        edges.sort(key=lambda e: -e[2])
        edges = edges[:max_edges]
        used_nodes = set()
        for a, b, _ in edges:
            used_nodes.add(a)
            used_nodes.add(b)

        nodes = []
        for n in top_nodes:
            if n not in used_nodes:
                continue
            col, val = n.split("::", 1)
            nodes.append(
                {
                    "id": n,
                    "label": str(val),
                    "type": col,
                    "count": int(node_count[n]),
                    "community": node_to_community.get(n, -1),
                }
            )
        edge_list = [{"from": a, "to": b, "weight": int(w)} for a, b, w in edges]
        return {"nodes": nodes, "edges": edge_list}

    # ---------------------------------------------------------------
    # ③ 類似Fault検索 (Graph Embedding + Similarity)
    # ---------------------------------------------------------------
    def find_similar(self, fault_index=None, attrs=None, top_k=10):
        if fault_index is not None:
            q = self.fault_embedding(fault_index)
        else:
            q = self.embed_query(attrs or {})
        fault_embs = self.all_fault_embeddings()
        sims = fault_embs @ q
        order = np.argsort(-sims)

        results = []
        for idx in order:
            if fault_index is not None and idx == fault_index:
                continue
            row = self.df.iloc[idx]
            item = {
                "fault_id": self.fault_ids[idx],
                "similarity": round(float(sims[idx]) * 100, 1),
                "attrs": {col: row[col] for col in self.attr_columns if pd.notna(row.get(col))},
            }
            if self.cause_column and pd.notna(row.get(self.cause_column)):
                item["cause"] = row[self.cause_column]
            if self.action_column and pd.notna(row.get(self.action_column)):
                item["action"] = row[self.action_column]
            if self.text_column and pd.notna(row.get(self.text_column)):
                item["note"] = row[self.text_column]
            results.append(item)
            if len(results) >= top_k:
                break
        return results

    # ---------------------------------------------------------------
    def attr_value_options(self):
        options = {}
        for col in self.attr_columns:
            vals = sorted([v for v in self.df[col].dropna().unique().tolist()])
            options[col] = vals
        return options

    def summary(self):
        return {
            "n_faults": len(self.df),
            "n_nodes": self.G.number_of_nodes(),
            "n_edges": self.G.number_of_edges(),
            "attr_columns": self.attr_columns,
            "cause_column": self.cause_column,
            "has_action": self.action_column is not None,
            "has_text": self.text_column is not None,
        }
