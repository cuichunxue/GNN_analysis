# -*- coding: utf-8 -*-
import io
import uuid
import traceback

import pandas as pd
from flask import Flask, request, jsonify, session, render_template

from graph_engine import (
    FaultGraphAnalyzer,
    DEFAULT_ATTR_COLUMNS,
    DEFAULT_CAUSE_COLUMN,
    DEFAULT_ACTION_COLUMN,
    DEFAULT_TEXT_COLUMN,
)
from sample_data import build_sample_dataframe

app = Flask(__name__)
app.secret_key = "fault-gnn-demo-secret-key"  # デモ用。本番運用時は環境変数等に置き換えてください。

# デモ用：メモリ内ストア（セッションID -> FaultGraphAnalyzer）
# ※ 複数プロセス/複数ワーカーで動かす場合は Redis 等の外部ストアに置き換えてください。
STORE: dict[str, FaultGraphAnalyzer] = {}


def _get_analyzer() -> FaultGraphAnalyzer:
    token = session.get("token")
    if not token or token not in STORE:
        raise KeyError("データが読み込まれていません。先にCSVアップロードまたはサンプルデータの読込を行ってください。")
    return STORE[token]


def _set_analyzer(analyzer: FaultGraphAnalyzer) -> str:
    token = str(uuid.uuid4())
    STORE[token] = analyzer
    session["token"] = token
    return token


def _build_response_after_load(analyzer: FaultGraphAnalyzer):
    return jsonify(
        {
            "ok": True,
            "summary": analyzer.summary(),
            "attr_options": analyzer.attr_value_options(),
            "cause_options": sorted(analyzer.df[analyzer.cause_column].dropna().unique().tolist())
            if analyzer.cause_column else [],
            "preview": analyzer.df.head(8).fillna("").to_dict(orient="records"),
            "columns": list(analyzer.df.columns),
        }
    )


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/load_sample", methods=["POST"])
def api_load_sample():
    df = build_sample_dataframe()
    analyzer = FaultGraphAnalyzer(df)
    _set_analyzer(analyzer)
    return _build_response_after_load(analyzer)


@app.route("/api/upload", methods=["POST"])
def api_upload():
    if "file" not in request.files:
        return jsonify({"ok": False, "error": "ファイルが見つかりません"}), 400
    f = request.files["file"]
    try:
        raw = f.read()
        try:
            df = pd.read_csv(io.BytesIO(raw), encoding="utf-8-sig")
        except UnicodeDecodeError:
            df = pd.read_csv(io.BytesIO(raw), encoding="cp932")
    except Exception as e:
        return jsonify({"ok": False, "error": f"CSVの読み込みに失敗しました: {e}"}), 400

    if df.empty:
        return jsonify({"ok": False, "error": "CSVにデータがありません"}), 400

    attr_columns = [c for c in DEFAULT_ATTR_COLUMNS if c in df.columns]
    if not attr_columns:
        # デフォルト列名が無い場合、原因/対策/備考以外の非数値列を属性列として推定
        exclude = {DEFAULT_CAUSE_COLUMN, DEFAULT_ACTION_COLUMN, DEFAULT_TEXT_COLUMN}
        attr_columns = [c for c in df.columns if c not in exclude][:8]

    try:
        analyzer = FaultGraphAnalyzer(df, attr_columns=attr_columns)
    except Exception as e:
        traceback.print_exc()
        return jsonify({"ok": False, "error": f"グラフ構築に失敗しました: {e}"}), 400

    _set_analyzer(analyzer)
    return _build_response_after_load(analyzer)


@app.route("/api/predict_cause", methods=["POST"])
def api_predict_cause():
    try:
        analyzer = _get_analyzer()
    except KeyError as e:
        return jsonify({"ok": False, "error": str(e)}), 400
    data = request.get_json(force=True) or {}
    attrs = data.get("attrs", {})
    top_k = int(data.get("top_k", 5))
    try:
        result = analyzer.predict_cause(attrs, top_k=top_k)
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 400
    return jsonify({"ok": True, "result": result})


@app.route("/api/discover_patterns", methods=["POST"])
def api_discover_patterns():
    try:
        analyzer = _get_analyzer()
    except KeyError as e:
        return jsonify({"ok": False, "error": str(e)}), 400
    data = request.get_json(force=True) or {}
    n_clusters = data.get("n_clusters")
    n_clusters = int(n_clusters) if n_clusters else None
    contamination = float(data.get("contamination", 0.08))
    try:
        result = analyzer.discover_patterns(n_clusters=n_clusters, contamination=contamination)
    except Exception as e:
        traceback.print_exc()
        return jsonify({"ok": False, "error": str(e)}), 400
    return jsonify({"ok": True, "result": result})


@app.route("/api/find_similar", methods=["POST"])
def api_find_similar():
    try:
        analyzer = _get_analyzer()
    except KeyError as e:
        return jsonify({"ok": False, "error": str(e)}), 400
    data = request.get_json(force=True) or {}
    top_k = int(data.get("top_k", 10))
    fault_id = data.get("fault_id")
    attrs = data.get("attrs")
    try:
        if fault_id:
            idx = analyzer.fault_ids.index(fault_id)
            result = analyzer.find_similar(fault_index=idx, top_k=top_k)
        else:
            result = analyzer.find_similar(attrs=attrs or {}, top_k=top_k)
    except ValueError:
        return jsonify({"ok": False, "error": f"Fault ID '{fault_id}' が見つかりません"}), 400
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 400
    return jsonify({"ok": True, "result": result})


@app.route("/api/fault_ids", methods=["GET"])
def api_fault_ids():
    try:
        analyzer = _get_analyzer()
    except KeyError as e:
        return jsonify({"ok": False, "error": str(e)}), 400
    return jsonify({"ok": True, "fault_ids": analyzer.fault_ids})


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
