// XSS対策: CSV由来の文字列は必ずこの関数を通してからinnerHTMLに入れる
function esc(s) {
  if (s === null || s === undefined) return "";
  return String(s)
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;").replace(/'/g, "&#39;");
}

let ATTR_OPTIONS = {};
const $ = (s) => document.querySelector(s);
const el = (t, c, h) => { const e = document.createElement(t); if (c) e.className = c; if (h !== undefined) e.innerHTML = h; return e; };

function setStatus(html, type = "info") {
  $("#loadStatus").innerHTML = `<div class="alert alert-${type} py-2 mb-0">${html}</div>`;
}
async function postJSON(url, body) {
  const r = await fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body || {}) });
  return r.json();
}
function errBox(sel, msg) { $(sel).innerHTML = `<div class="alert alert-danger">${esc(msg)}</div>`; }
function spin(sel, txt) { $(sel).innerHTML = `<i class="fa-solid fa-spinner fa-spin"></i> ${esc(txt)}`; }

// ---------- データ読込 ----------
$("#btnSample").addEventListener("click", async () => {
  setStatus('<i class="fa-solid fa-spinner fa-spin me-1"></i>サンプルデータを生成中...');
  handleLoad(await (await fetch("/api/load_sample", { method: "POST" })).json());
});

$("#btnUpload").addEventListener("click", async () => {
  const f = $("#csvFile");
  if (!f.files.length) return setStatus("CSVファイルを選択してください。", "warning");
  setStatus('<i class="fa-solid fa-spinner fa-spin me-1"></i>解析中...');
  const fd = new FormData(); fd.append("file", f.files[0]);
  try {
    handleLoad(await (await fetch("/api/upload", { method: "POST", body: fd })).json());
  } catch (e) { setStatus("アップロードに失敗しました。", "danger"); }
});

function handleLoad(d) {
  if (!d.ok) return setStatus(`<i class="fa-solid fa-triangle-exclamation me-1"></i>${esc(d.error)}`, "danger");
  const s = d.summary;
  let msg = `<i class="fa-solid fa-circle-check me-1"></i>読込完了：${s.n_faults}件 / ${s.n_nodes}ノード / ${s.n_edges}エッジ（埋め込み${s.embed_dim}次元）`;
  if (s.dropped_columns && s.dropped_columns.length) {
    msg += `<br><span class="small">※ 値の種類が多すぎる列を属性から除外しました: ` +
      s.dropped_columns.map((c) => `${esc(c.column)}(${c.n_unique}種)`).join(", ") + `</span>`;
  }
  if (!s.date_column) msg += `<br><span class="small">※ 日付列(発生日)がないため「急増検知」は無効です。</span>`;
  setStatus(msg, "success");

  ATTR_OPTIONS = d.attr_options;
  renderSummary(s); renderPreview(d.columns, d.preview);
  buildForm("#causeAttrForm", "cause_"); buildForm("#simNewBlock", "sim_");
  loadFaultIds();
  $("#dataSummary").classList.remove("d-none");
  $("#analysisCard").classList.remove("d-none");
}

function renderSummary(s) {
  const w = $("#summaryCards"); w.innerHTML = "";
  [["Fault件数", s.n_faults], ["ノード数", s.n_nodes], ["エッジ数", s.n_edges],
   ["埋め込み次元", s.embed_dim], ["原因列", s.cause_column || "なし"], ["日付列", s.date_column || "なし"]]
    .forEach(([l, v]) => {
      const c = el("div", "col-auto summary-chip");
      c.innerHTML = `<div class="val">${esc(v)}</div><div class="lbl">${esc(l)}</div>`;
      w.appendChild(c);
    });
}

function renderPreview(cols, rows) {
  $("#previewTable").innerHTML =
    "<thead><tr>" + cols.map((c) => `<th>${esc(c)}</th>`).join("") + "</tr></thead><tbody>" +
    rows.map((r) => "<tr>" + cols.map((c) => `<td>${esc(r[c])}</td>`).join("") + "</tr>").join("") + "</tbody>";
}

function buildForm(sel, prefix) {
  const w = $(sel); w.innerHTML = "";
  Object.entries(ATTR_OPTIONS).forEach(([col, vals]) => {
    const d = el("div", "col-md-4");
    d.innerHTML = `<label class="form-label small text-muted">${esc(col)}</label>
      <select class="form-select" id="${prefix}${esc(col)}" data-col="${esc(col)}">
      <option value="">（未選択）</option>${vals.map((v) => `<option value="${esc(v)}">${esc(v)}</option>`).join("")}</select>`;
    w.appendChild(d);
  });
}

async function loadFaultIds() {
  const d = await (await fetch("/api/fault_ids")).json();
  if (!d.ok) return;
  $("#simFaultId").innerHTML = d.fault_ids.map((f) => `<option value="${esc(f)}">${esc(f)}</option>`).join("");
}

// ---------- タブ ----------
document.querySelectorAll("#methodTabs .nav-link").forEach((b) => {
  b.addEventListener("click", () => {
    document.querySelectorAll("#methodTabs .nav-link").forEach((x) => x.classList.remove("active"));
    b.classList.add("active");
    document.querySelectorAll(".tab-pane").forEach((p) => p.classList.add("d-none"));
    $("#pane-" + b.dataset.tab).classList.remove("d-none");
  });
});
document.querySelectorAll('input[name="simMode"]').forEach((r) =>
  r.addEventListener("change", () => {
    const e = $("#simModeExisting").checked;
    $("#simExistingBlock").classList.toggle("d-none", !e);
    $("#simNewBlock").classList.toggle("d-none", e);
  }));

function collect(prefix) {
  const a = {};
  Object.keys(ATTR_OPTIONS).forEach((c) => { const v = $("#" + prefix + c).value; if (v) a[c] = v; });
  return a;
}

// ---------- ① 原因予測 ----------
$("#btnPredictCause").addEventListener("click", async () => {
  spin("#causeResult", "予測中...");
  const d = await postJSON("/api/predict_cause", { attrs: collect("cause_"), top_k: 5 });
  if (!d.ok) return errBox("#causeResult", d.error);
  if (!d.result.length) return ($("#causeResult").innerHTML = `<div class="alert alert-warning">属性を1つ以上選択してください。</div>`);
  const box = $("#causeResult"); box.innerHTML = "";
  d.result.forEach((r) => {
    const c = el("div", "result-card");
    c.innerHTML = `<div class="d-flex justify-content-between align-items-center mb-2">
        <div class="fw-bold fs-5">${esc(r.cause)}</div>
        <div class="fs-5 fw-bold" style="color:#4f46e5">${esc(r.probability)}%</div></div>
      <div class="cause-bar-wrap mb-2"><div class="cause-bar" style="width:${Number(r.probability)}%"></div></div>
      <div class="small-muted mb-1">根拠となった類似過去Fault：</div>
      <div>${r.evidence.map((e) => `<span class="attr-tag">${esc(e.fault_id)} ${esc(e.similarity)}%</span>`).join("")}</div>`;
    box.appendChild(c);
  });
});

// ---------- 精度評価 ----------
$("#btnEvaluate").addEventListener("click", async () => {
  spin("#evalResult", "ホールドアウト評価を実行中...");
  const d = await postJSON("/api/evaluate", {});
  if (!d.ok) return errBox("#evalResult", d.error);
  const r = d.result;
  $("#evalResult").innerHTML = `
    <div class="small-muted mb-2">学習${r.n_train}件 / 検証${r.n_test}件 / 原因${r.n_classes}クラス（層化ホールドアウト）</div>
    <table class="table table-sm table-bordered align-middle">
      <thead><tr><th>モデル</th><th>Top-1 正解率</th><th>Top-3 正解率</th></tr></thead>
      <tbody>${r.rows.map((x) => `<tr><td>${esc(x.model)}</td>
        <td><b>${esc(x.top1)}</b></td><td>${x.top3 === null ? "-" : "<b>" + esc(x.top3) + "</b>"}</td></tr>`).join("")}</tbody>
    </table>
    <div class="alert alert-warning py-2 small mb-0">
      勾配ブースティングが埋め込みkNNと同等以上なら、原因予測は表形式モデルを本番採用し、
      グラフ/埋め込みは②パターン発見・③類似検索に使うのが合理的です。</div>`;
});

// ---------- ② パターン発見 ----------
$("#btnDiscover").addEventListener("click", async () => {
  spin("#patternResult", "解析中...");
  const d = await postJSON("/api/discover_patterns", {
    n_clusters: $("#nClusters").value || null,
    contamination: parseFloat($("#contamination").value || "0.08"),
    recent_days: parseInt($("#recentDays").value || "90"),
  });
  if (!d.ok) return errBox("#patternResult", d.error);
  const r = d.result, box = $("#patternResult"); box.innerHTML = "";

  // 急増検知
  box.appendChild(el("h6", "cluster-title mb-2", '<i class="fa-solid fa-arrow-trend-up me-1"></i>直近の急増パターン'));
  if (!r.surges.available) {
    box.appendChild(el("div", "alert alert-secondary py-2 small", esc(r.surges.reason)));
  } else if (!r.surges.items.length) {
    box.appendChild(el("div", "alert alert-success py-2 small", "急増している属性組合せは検出されませんでした。"));
  } else {
    const t = el("div", "table-responsive mb-4");
    t.innerHTML = `<div class="small-muted mb-1">直近${esc(r.surges.recent_days)}日(${esc(r.surges.n_recent)}件) vs それ以前(${esc(r.surges.n_prev)}件)</div>
      <table class="table table-sm table-bordered align-middle"><thead><tr>
      <th>パターン</th><th>直近件数</th><th>以前の構成比</th><th>直近の構成比</th><th>増加倍率</th></tr></thead><tbody>
      ${r.surges.items.map((s) => `<tr><td>${esc(s.pattern)}</td><td>${esc(s.recent_count)}</td>
        <td>${esc(s.prev_share)}%</td><td><b>${esc(s.recent_share)}%</b></td>
        <td><span class="badge badge-anomaly">${esc(s.lift)}</span></td></tr>`).join("")}</tbody></table>`;
    box.appendChild(t);
  }

  // クラスタ
  const kInfo = r.chosen_k ? `（シルエット係数でk=${esc(r.chosen_k)}を自動選択）` : "";
  box.appendChild(el("h6", "cluster-title mb-2", `<i class="fa-solid fa-layer-group me-1"></i>頻出パターン${kInfo}`));
  const cr = el("div", "row g-3 mb-4");
  r.clusters.forEach((c) => {
    const col = el("div", "col-md-6");
    col.innerHTML = `<div class="result-card h-100">
      <div class="d-flex justify-content-between"><div class="fw-bold">クラスタ #${esc(c.cluster_id)}</div>
      <span class="badge bg-secondary">${esc(c.size)}件</span></div>
      <div class="mt-2">${c.features.map((f) => `<span class="attr-tag">${esc(f.col)}: ${esc(f.val)}
        <b>${esc(f.share)}%</b> <span style="color:#b91c1c">×${esc(f.lift)}</span></span>`).join("")}</div>
      ${c.top_cause ? `<div class="small-muted mt-2">主な原因: ${esc(c.top_cause)}</div>` : ""}</div>`;
    cr.appendChild(col);
  });
  box.appendChild(cr);
  box.appendChild(el("div", "small-muted mb-4", "※ ×n はリフト値（全体平均比での出現しやすさ）。値が大きいほどそのクラスタ固有の特徴です。"));

  // 異常検知
  box.appendChild(el("h6", "cluster-title mb-2", '<i class="fa-solid fa-triangle-exclamation me-1"></i>外れ値Fault（異常検知）'));
  if (!r.anomalies.length) {
    box.appendChild(el("div", "text-muted small mb-4", "明確な外れ値は検出されませんでした。"));
  } else {
    const t = el("div", "table-responsive mb-4");
    t.innerHTML = `<table class="table table-sm table-bordered align-middle">
      <thead><tr><th>Fault ID</th><th>属性の組合せ</th><th>原因</th><th>異常スコア</th></tr></thead><tbody>
      ${r.anomalies.map((a) => `<tr><td><span class="badge badge-anomaly">${esc(a.fault_id)}</span></td>
        <td>${Object.entries(a.attrs).map(([k, v]) => `<span class="attr-tag">${esc(k)}: ${esc(v)}</span>`).join("")}</td>
        <td>${esc(a.cause || "-")}</td><td>${esc(a.anomaly_score)}</td></tr>`).join("")}</tbody></table>`;
    box.appendChild(t);
  }

  renderNetwork(r.network);
});

// ---------- 共起ネットワーク ----------
let NET = null;
const PALETTE = ["#4f46e5","#059669","#d97706","#db2777","#0891b2","#7c3aed","#ca8a04","#dc2626","#16a34a","#2563eb"];
const colorFor = (c) => (c === -1 || c == null ? "#9ca3af" : PALETTE[c % PALETTE.length]);

function renderNetwork(nd) {
  const box = $("#networkGraph"), lg = $("#networkLegend");
  if (!nd || !nd.nodes.length) {
    box.innerHTML = '<div class="d-flex align-items-center justify-content-center h-100 text-muted small">描画データが不足しています。</div>';
    lg.innerHTML = ""; return;
  }
  lg.innerHTML = [...new Set(nd.nodes.map((n) => n.community))].sort((a, b) => a - b)
    .map((c) => `<span class="attr-tag" style="border-left:4px solid ${colorFor(c)}">${c === -1 ? "その他" : "コミュニティ #" + esc(c)}</span>`).join("");

  const nodes = new vis.DataSet(nd.nodes.map((n) => ({
    id: n.id, label: n.label,
    title: `${n.type}: ${n.label}\n出現数: ${n.count}\nコミュニティ: ${n.community === -1 ? "その他" : "#" + n.community}`,
    value: n.count, color: { background: colorFor(n.community), border: "#333" }, font: { size: 13 },
  })));
  const mx = Math.max(...nd.edges.map((e) => e.weight), 1);
  const edges = new vis.DataSet(nd.edges.map((e) => ({
    from: e.from, to: e.to, value: e.weight, title: `共起回数: ${e.weight}`,
    color: { color: "#c7cae8", opacity: 0.3 + 0.5 * (e.weight / mx) },
  })));
  if (NET) NET.destroy();
  box.innerHTML = "";
  NET = new vis.Network(box, { nodes, edges }, {
    nodes: { shape: "dot", scaling: { min: 10, max: 40 }, borderWidth: 1 },
    edges: { smooth: { type: "continuous" }, scaling: { min: 1, max: 8 } },
    physics: { stabilization: { iterations: 150 }, barnesHut: { gravitationalConstant: -4000, springLength: 130, springConstant: 0.02 } },
    interaction: { hover: true, tooltipDelay: 100 },
  });
}

// ---------- ③ 類似検索 ----------
$("#btnFindSimilar").addEventListener("click", async () => {
  spin("#similarResult", "検索中...");
  const p = { top_k: parseInt($("#simTopK").value || "10") };
  if ($("#simModeExisting").checked) p.fault_id = $("#simFaultId").value;
  else p.attrs = collect("sim_");
  const d = await postJSON("/api/find_similar", p);
  if (!d.ok) return errBox("#similarResult", d.error);
  if (!d.result.length) return ($("#similarResult").innerHTML = `<div class="alert alert-warning">結果が見つかりませんでした。</div>`);
  $("#similarResult").innerHTML = `<div class="table-responsive"><table class="table table-sm table-bordered align-middle">
    <thead><tr><th>類似度</th><th>Fault ID</th><th>発生日</th><th>属性</th><th>原因</th><th>対策</th></tr></thead><tbody>
    ${d.result.map((r) => `<tr><td><span class="badge badge-sim">${esc(r.similarity)}%</span></td>
      <td>${esc(r.fault_id)}</td><td class="small-muted">${esc(r.date || "-")}</td>
      <td>${Object.entries(r.attrs).map(([k, v]) => `<span class="attr-tag">${esc(k)}: ${esc(v)}</span>`).join("")}</td>
      <td>${esc(r.cause || "-")}</td><td class="small-muted">${esc(r.action || "-")}</td></tr>`).join("")}
    </tbody></table></div>`;
});
