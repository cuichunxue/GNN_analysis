let ATTR_OPTIONS = {};
let CAUSE_OPTIONS = [];
let FAULT_IDS = [];

const $ = (sel) => document.querySelector(sel);
const el = (tag, cls, html) => {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (html !== undefined) e.innerHTML = html;
  return e;
};

function setStatus(html, type = "info") {
  $("#loadStatus").innerHTML = `<div class="alert alert-${type} py-2 mb-0">${html}</div>`;
}

async function postJSON(url, body) {
  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body || {}),
  });
  return res.json();
}

// ---------------- データ読込 ----------------

$("#btnSample").addEventListener("click", async () => {
  setStatus('<i class="fa-solid fa-spinner fa-spin me-1"></i>サンプルデータを生成しグラフを構築しています...');
  const res = await fetch("/api/load_sample", { method: "POST" });
  const data = await res.json();
  handleLoadResponse(data);
});

$("#btnUpload").addEventListener("click", async () => {
  const fileInput = $("#csvFile");
  if (!fileInput.files.length) {
    setStatus("CSVファイルを選択してください。", "warning");
    return;
  }
  setStatus('<i class="fa-solid fa-spinner fa-spin me-1"></i>アップロード中・グラフを構築しています...');
  const fd = new FormData();
  fd.append("file", fileInput.files[0]);
  const res = await fetch("/api/upload", { method: "POST", body: fd });
  const data = await res.json();
  handleLoadResponse(data);
});

function handleLoadResponse(data) {
  if (!data.ok) {
    setStatus(`<i class="fa-solid fa-triangle-exclamation me-1"></i>${data.error}`, "danger");
    return;
  }
  setStatus(
    `<i class="fa-solid fa-circle-check me-1"></i>読み込み完了：${data.summary.n_faults}件のFaultから ${data.summary.n_nodes}ノード / ${data.summary.n_edges}エッジのグラフを構築しました。`,
    "success"
  );
  ATTR_OPTIONS = data.attr_options;
  CAUSE_OPTIONS = data.cause_options;

  renderSummaryCards(data.summary);
  renderPreview(data.columns, data.preview);
  buildAttrForm("#causeAttrForm", "cause_");
  buildAttrForm("#simNewBlock", "sim_");
  loadFaultIds();

  $("#dataSummary").classList.remove("d-none");
  $("#analysisCard").classList.remove("d-none");
}

function renderSummaryCards(summary) {
  const wrap = $("#summaryCards");
  wrap.innerHTML = "";
  const chips = [
    ["Fault件数", summary.n_faults],
    ["グラフノード数", summary.n_nodes],
    ["グラフエッジ数", summary.n_edges],
    ["属性列", summary.attr_columns.join(" / ")],
    ["原因列", summary.cause_column || "なし"],
  ];
  chips.forEach(([lbl, val]) => {
    const chip = el("div", "col-auto summary-chip");
    chip.innerHTML = `<div class="val">${val}</div><div class="lbl">${lbl}</div>`;
    wrap.appendChild(chip);
  });
}

function renderPreview(columns, rows) {
  const table = $("#previewTable");
  let thead = "<thead><tr>" + columns.map((c) => `<th>${c}</th>`).join("") + "</tr></thead>";
  let tbody =
    "<tbody>" +
    rows.map((r) => "<tr>" + columns.map((c) => `<td>${r[c] ?? ""}</td>`).join("") + "</tr>").join("") +
    "</tbody>";
  table.innerHTML = thead + tbody;
}

function buildAttrForm(containerSel, prefix) {
  const wrap = $(containerSel);
  wrap.innerHTML = "";
  Object.entries(ATTR_OPTIONS).forEach(([col, values]) => {
    const colDiv = el("div", "col-md-4");
    const id = prefix + col;
    let optionsHtml = '<option value="">（未選択）</option>' + values.map((v) => `<option value="${v}">${v}</option>`).join("");
    colDiv.innerHTML = `
      <label class="form-label small text-muted">${col}</label>
      <select class="form-select" id="${id}" data-col="${col}">${optionsHtml}</select>
    `;
    wrap.appendChild(colDiv);
  });
}

async function loadFaultIds() {
  const res = await fetch("/api/fault_ids");
  const data = await res.json();
  if (!data.ok) return;
  FAULT_IDS = data.fault_ids;
  const sel = $("#simFaultId");
  sel.innerHTML = FAULT_IDS.map((f) => `<option value="${f}">${f}</option>`).join("");
}

// ---------------- タブ切替 ----------------

document.querySelectorAll("#methodTabs .nav-link").forEach((btn) => {
  btn.addEventListener("click", () => {
    document.querySelectorAll("#methodTabs .nav-link").forEach((b) => b.classList.remove("active"));
    btn.classList.add("active");
    document.querySelectorAll(".tab-pane").forEach((p) => p.classList.add("d-none"));
    $("#pane-" + btn.dataset.tab).classList.remove("d-none");
  });
});

document.querySelectorAll('input[name="simMode"]').forEach((r) => {
  r.addEventListener("change", () => {
    const useExisting = $("#simModeExisting").checked;
    $("#simExistingBlock").classList.toggle("d-none", !useExisting);
    $("#simNewBlock").classList.toggle("d-none", useExisting);
  });
});

// ---------------- ① 原因予測 ----------------

function collectAttrs(prefix) {
  const attrs = {};
  Object.keys(ATTR_OPTIONS).forEach((col) => {
    const val = $("#" + prefix + col).value;
    if (val) attrs[col] = val;
  });
  return attrs;
}

$("#btnPredictCause").addEventListener("click", async () => {
  const attrs = collectAttrs("cause_");
  const box = $("#causeResult");
  box.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> 予測中...';
  const data = await postJSON("/api/predict_cause", { attrs, top_k: 5 });
  if (!data.ok) {
    box.innerHTML = `<div class="alert alert-danger">${data.error}</div>`;
    return;
  }
  if (!data.result.length) {
    box.innerHTML = `<div class="alert alert-warning">属性を1つ以上選択してください。</div>`;
    return;
  }
  box.innerHTML = "";
  data.result.forEach((r) => {
    const card = el("div", "result-card");
    const evidence = r.evidence
      .map((e) => `<span class="attr-tag">${e.fault_id} 類似度${e.similarity}%</span>`)
      .join("");
    card.innerHTML = `
      <div class="d-flex justify-content-between align-items-center mb-2">
        <div class="fw-bold fs-5">${r.cause}</div>
        <div class="fs-5 fw-bold" style="color:#4f46e5">${r.probability}%</div>
      </div>
      <div class="d-flex align-items-center gap-2 mb-2">
        <div class="cause-bar-wrap"><div class="cause-bar" style="width:${r.probability}%"></div></div>
      </div>
      <div class="small-muted mb-1">根拠となった類似過去Fault：</div>
      <div>${evidence}</div>
    `;
    box.appendChild(card);
  });
});

// ---------------- ② 未知パターン発見 ----------------

$("#btnDiscover").addEventListener("click", async () => {
  const box = $("#patternResult");
  box.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> 解析中...';
  const nClusters = $("#nClusters").value || null;
  const contamination = parseFloat($("#contamination").value || "0.08");
  const data = await postJSON("/api/discover_patterns", { n_clusters: nClusters, contamination });
  if (!data.ok) {
    box.innerHTML = `<div class="alert alert-danger">${data.error}</div>`;
    return;
  }
  const r = data.result;
  box.innerHTML = "";

  // クラスタ
  box.appendChild(el("h6", "cluster-title mb-2", '<i class="fa-solid fa-layer-group me-1"></i>頻出パターン（クラスタリング）'));
  const clusterRow = el("div", "row g-3 mb-4");
  r.clusters.forEach((c) => {
    const attrsHtml = Object.entries(c.top_attrs)
      .map(([k, v]) => `<span class="attr-tag">${k}: ${v}</span>`)
      .join("");
    const col = el("div", "col-md-6");
    col.innerHTML = `
      <div class="result-card h-100">
        <div class="d-flex justify-content-between">
          <div class="fw-bold">クラスタ #${c.cluster_id}</div>
          <span class="badge bg-secondary">${c.size}件</span>
        </div>
        <div class="mt-2">${attrsHtml}</div>
        ${c.top_cause ? `<div class="small-muted mt-2">主な原因: ${c.top_cause}</div>` : ""}
        <div class="small-muted mt-2">例: ${c.fault_ids.join(", ")}</div>
      </div>`;
    clusterRow.appendChild(col);
  });
  box.appendChild(clusterRow);

  // 異常検知
  box.appendChild(
    el(
      "h6",
      "cluster-title mb-2",
      '<i class="fa-solid fa-triangle-exclamation me-1"></i>未知・急増パターン候補（異常検知）'
    )
  );
  if (!r.anomalies.length) {
    box.appendChild(el("div", "text-muted small mb-4", "検出されたデータ件数が少ないか、明確な異常は見つかりませんでした。"));
  } else {
    const table = el("div", "table-responsive mb-4");
    let rows = r.anomalies
      .map((a) => {
        const attrsHtml = Object.entries(a.attrs)
          .map(([k, v]) => `<span class="attr-tag">${k}: ${v}</span>`)
          .join("");
        return `<tr>
          <td><span class="badge badge-anomaly">${a.fault_id}</span></td>
          <td>${attrsHtml}</td>
          <td>${a.cause || "-"}</td>
          <td>${a.anomaly_score}</td>
        </tr>`;
      })
      .join("");
    table.innerHTML = `
      <table class="table table-sm table-bordered align-middle">
        <thead><tr><th>Fault ID</th><th>属性の組合せ</th><th>原因</th><th>異常スコア</th></tr></thead>
        <tbody>${rows}</tbody>
      </table>`;
    box.appendChild(table);
  }

  // コミュニティ検出
  box.appendChild(
    el("h6", "cluster-title mb-2", '<i class="fa-solid fa-circle-nodes me-1"></i>関連コミュニティ（Community Detection）')
  );
  if (!r.communities.length) {
    box.appendChild(el("div", "text-muted small", "明確なコミュニティ構造は検出されませんでした。"));
  } else {
    const commRow = el("div", "row g-3");
    r.communities.forEach((c) => {
      const col = el("div", "col-md-6");
      const keyAttrs = c.key_attrs.map((k) => `<span class="attr-tag">${k}</span>`).join("");
      col.innerHTML = `
        <div class="result-card h-100">
          <div class="d-flex justify-content-between">
            <div class="fw-bold">コミュニティ #${c.community_id}</div>
            <span class="badge bg-secondary">${c.n_faults}件のFault</span>
          </div>
          <div class="mt-2">${keyAttrs}</div>
        </div>`;
      commRow.appendChild(col);
    });
    box.appendChild(commRow);
  }

  renderCooccurrenceNetwork(r.network);
});

// ---------------- 共起ネットワーク（vis-network） ----------------

let NETWORK_INSTANCE = null;
const GROUP_PALETTE = [
  "#4f46e5", "#059669", "#d97706", "#db2777", "#0891b2",
  "#7c3aed", "#ca8a04", "#dc2626", "#16a34a", "#2563eb",
  "#9333ea", "#0d9488", "#c2410c", "#4338ca", "#65a30d",
];
const OTHER_COLOR = "#9ca3af";

function colorForCommunity(cid) {
  if (cid === -1 || cid === undefined || cid === null) return OTHER_COLOR;
  return GROUP_PALETTE[cid % GROUP_PALETTE.length];
}

function renderCooccurrenceNetwork(networkData) {
  const container = $("#networkGraph");
  const legend = $("#networkLegend");

  if (!networkData || !networkData.nodes.length) {
    container.innerHTML = '<div class="d-flex align-items-center justify-content-center h-100 text-muted small">共起ネットワークを描画するデータが不足しています。</div>';
    legend.innerHTML = "";
    return;
  }

  const communityIds = [...new Set(networkData.nodes.map((n) => n.community))].sort((a, b) => a - b);
  legend.innerHTML = communityIds
    .map((cid) => {
      const color = colorForCommunity(cid);
      const label = cid === -1 ? "その他（未分類）" : `コミュニティ #${cid}`;
      return `<span class="attr-tag" style="border-left:4px solid ${color}">${label}</span>`;
    })
    .join("");

  const nodes = new vis.DataSet(
    networkData.nodes.map((n) => ({
      id: n.id,
      label: n.label,
      title: `${n.type}: ${n.label}\n出現数: ${n.count}\nコミュニティ: ${n.community === -1 ? "その他" : "#" + n.community}`,
      value: n.count,
      color: { background: colorForCommunity(n.community), border: "#333333", highlight: { background: colorForCommunity(n.community) } },
      font: { size: 13, color: "#222" },
    }))
  );
  const maxWeight = Math.max(...networkData.edges.map((e) => e.weight), 1);
  const edges = new vis.DataSet(
    networkData.edges.map((e) => ({
      from: e.from,
      to: e.to,
      value: e.weight,
      title: `共起回数: ${e.weight}`,
      color: { color: "#c7cae8", opacity: 0.3 + 0.5 * (e.weight / maxWeight) },
    }))
  );

  if (NETWORK_INSTANCE) {
    NETWORK_INSTANCE.destroy();
  }
  container.innerHTML = "";
  const data = { nodes, edges };
  const options = {
    nodes: { shape: "dot", scaling: { min: 10, max: 40 }, borderWidth: 1 },
    edges: { smooth: { type: "continuous" }, scaling: { min: 1, max: 8 } },
    physics: {
      stabilization: { iterations: 150 },
      barnesHut: { gravitationalConstant: -4000, springLength: 130, springConstant: 0.02 },
    },
    interaction: { hover: true, tooltipDelay: 100 },
  };
  NETWORK_INSTANCE = new vis.Network(container, data, options);
}

// ---------------- ③ 類似Fault検索 ----------------

$("#btnFindSimilar").addEventListener("click", async () => {
  const box = $("#similarResult");
  box.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> 検索中...';
  const topK = parseInt($("#simTopK").value || "10");
  let payload = { top_k: topK };
  if ($("#simModeExisting").checked) {
    payload.fault_id = $("#simFaultId").value;
  } else {
    payload.attrs = collectAttrs("sim_");
  }
  const data = await postJSON("/api/find_similar", payload);
  if (!data.ok) {
    box.innerHTML = `<div class="alert alert-danger">${data.error}</div>`;
    return;
  }
  if (!data.result.length) {
    box.innerHTML = `<div class="alert alert-warning">結果が見つかりませんでした。属性を選択するか別のFaultIDをお試しください。</div>`;
    return;
  }
  const table = el("div", "table-responsive");
  let rows = data.result
    .map((r) => {
      const attrsHtml = Object.entries(r.attrs)
        .map(([k, v]) => `<span class="attr-tag">${k}: ${v}</span>`)
        .join("");
      return `<tr>
        <td><span class="badge badge-sim">${r.similarity}%</span></td>
        <td>${r.fault_id}</td>
        <td>${attrsHtml}</td>
        <td>${r.cause || "-"}</td>
        <td>${r.action || "-"}</td>
        <td class="small-muted">${r.note || "-"}</td>
      </tr>`;
    })
    .join("");
  table.innerHTML = `
    <table class="table table-sm table-bordered align-middle">
      <thead><tr><th>類似度</th><th>Fault ID</th><th>属性</th><th>原因</th><th>対策</th><th>備考</th></tr></thead>
      <tbody>${rows}</tbody>
    </table>`;
  box.innerHTML = "";
  box.appendChild(table);
});
