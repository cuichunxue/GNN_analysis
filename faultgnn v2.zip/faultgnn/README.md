# Fault Management GNN Analyzer

Fault Management（設備故障管理）データを異種グラフ（Heterogeneous Graph）として構築し、
簡易GNN（SGC: Simple Graph Convolution方式 = 正規化隣接行列によるK-hop特徴伝播）で
ノード埋め込みを計算した上で、以下の3手法を1つのFlask Webアプリで自由に選んで実行できます。

| 手法 | やること | 内部アルゴリズム |
|---|---|---|
| ① 原因予測 | 新規Faultの属性から原因候補を確率付きで推定 | Node Classification / Link Prediction相当（埋め込み近傍のkNN重み付き投票） |
| ② 未知パターン発見 | 頻出パターン・急増中の未知パターンを発見 | Embedding + KMeansクラスタリング / IsolationForest異常検知 / Community Detection（modularity） |
| ③ 類似Fault検索 | 今回のFaultと似た過去事例を原因・対策とともに検索 | Graph Embedding + Cosine Similarity |

## セットアップ

```bash
python3 -m venv venv
source venv/bin/activate  # Windowsは venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

ブラウザで `http://127.0.0.1:5000` を開いてください。

## 使い方

1. **STEP1**: 自分のFault管理CSVをアップロードするか、「サンプルデータで試す」ボタンでデモデータを生成します。
   - CSVの推奨列名: `装置, 部品, 症状, Error, 条件, 工程, 原因, 対策, 備考`
   - 列名が異なっていても、`原因/対策/備考`以外の列を自動的に属性列として推定して動作します（原因列がない場合は①原因予測は使えません）。
2. **STEP2**: タブで3手法を切り替えて実行します。
   - **① 原因予測**: 属性を1つ以上選んで「原因を予測する」。原因候補が確率順に、根拠となった過去Faultとともに表示されます。
   - **② 未知パターン発見**: クラスタ数（空欄で自動）・異常検知感度を指定して実行。頻出クラスタ・異常（未知/急増）パターン・関連コミュニティが表示されます。
   - **③ 類似Fault検索**: 既存のFault IDから検索するか、新規属性を入力して検索。類似度の高い過去事例が原因・対策・備考付きで表示されます。

## 同梱サンプルデータについて

`sample_data.py` は元資料の例（Motor×高温で摩耗が多発、装置B×E205×夜間×高湿度が最近急増している未知パターン）
を模した相関構造をあえて仕込んだデモ用データ（約400件）を生成します。
「② 未知パターン発見」の異常検知タブで、この装置B×E205パターンが検出されることを確認できます。

## 実装メモ

- グラフ構築: `networkx` でFaultノードと各属性値ノード（装置/部品/症状/Error/条件/工程/原因）を接続した異種グラフを構築。
- 埋め込み計算: ノード種別ごとのランダム初期特徴 → 正規化隣接行列 `A_hat` によるK-hop伝播（SGC: Wu et al., 2019のSimplifying GCNと同型の演算）で構造を反映した埋め込みを生成。学習済み重みを使わない軽量実装のため、GPUや`torch`不要で動作します。
- ①③はこの埋め込み空間でのコサイン類似度、②は`scikit-learn`のKMeans / IsolationForest、コミュニティ検出は`networkx`のgreedy modularityを使用。
- デモ用に **セッションごとの解析結果をメモリ内(`STORE`辞書)に保持**しています。本番運用や複数ワーカー構成にする場合はRedis等の外部ストアに置き換えてください。

## ファイル構成

```
faultgnn/
├── app.py              # Flaskアプリ本体・APIエンドポイント
├── graph_engine.py      # グラフ構築・簡易GNN・3手法のコアロジック
├── sample_data.py        # デモ用サンプルデータ生成
├── requirements.txt
├── templates/
│   └── index.html        # SPA的な単一画面UI
└── static/
    ├── style.css
    └── app.js             # フロントエンドロジック（fetch API呼び出し・描画）
```
